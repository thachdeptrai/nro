public abstract class Effect2
{
	public static MyVector vEffect3 = new MyVector();

	public static MyVector vEffect2 = new MyVector();

	public static MyVector vRemoveEffect2 = new MyVector();

	public static MyVector vEffect2Outside = new MyVector();

	public static MyVector vAnimateEffect = new MyVector();

	public static MyVector vEffectFeet = new MyVector();

	public virtual void update()
	{
	}

	public virtual void paint(mGraphics g)
	{
	}
}
