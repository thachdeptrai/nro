public class NpcTemplate
{
	public int npcTemplateId;

	public string name;

	public int headId;

	public int bodyId;

	public int legId;

	public string[][] menu;
}
