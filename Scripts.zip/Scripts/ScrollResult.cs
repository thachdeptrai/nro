public class ScrollResult
{
	public bool isDowning;

	public int selected = -1;

	public bool isFinish;
}
