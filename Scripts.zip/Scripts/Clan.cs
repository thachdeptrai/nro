public class Clan
{
	public int ID;

	public int imgID;

	public string name = string.Empty;

	public string slogan = string.Empty;

	public int date;

	public string powerPoint;

	public int currMember;

	public int maxMember = 50;

	public int leaderID;

	public string leaderName;

	public int level;

	public int clanPoint;
}
