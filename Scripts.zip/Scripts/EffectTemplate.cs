public class EffectTemplate
{
	public sbyte id;

	public sbyte type;

	public int iconId;

	public string name;
}
