public class SmallDart
{
	public int index;

	public int x;

	public int y;

	public SmallDart(int x, int y)
	{
		this.x = x;
		this.y = y;
	}
}
