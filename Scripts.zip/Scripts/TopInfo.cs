public class TopInfo
{
	public int headID;

	public int headICON = -1;

	public short body;

	public short leg;

	public string name;

	public string info;

	public int pId;

	public int rank;

	public string info2;
}
