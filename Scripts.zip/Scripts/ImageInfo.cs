public class ImageInfo
{
	public int ID;

	public int x;

	public int y;

	public int x0;

	public int y0;

	public int w;

	public int h;
}
