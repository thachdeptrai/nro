public class ClanObject
{
	public int clanID;

	public int code;
}
