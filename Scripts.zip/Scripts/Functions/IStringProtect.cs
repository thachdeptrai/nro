﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assets.Script.Functions
{
    interface IStringProtect
    {
        string Hex2String(string A_0, object A_1);
        string ReverseString(string input);
    }
}
