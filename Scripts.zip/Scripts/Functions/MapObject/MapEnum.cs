﻿using System;

namespace MapObject
{
	// Token: 0x020000CD RID: 205
	public enum MapEnum
	{
		// Token: 0x04001347 RID: 4935
		AutoWaypoint,
		// Token: 0x04001348 RID: 4936
		NpcMenu,
		// Token: 0x04001349 RID: 4937
		NpcPanel,
		// Token: 0x0400134A RID: 4938
		Position,
		// Token: 0x0400134B RID: 4939
		Capsule
	}
}
