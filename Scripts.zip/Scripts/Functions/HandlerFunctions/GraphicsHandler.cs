﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Functions.HandlerFunctions
{
  internal class GraphicsHandler
{
		static GraphicsHandler()
        {
			listchar = true;
        }
		public static bool xoamap;
		public static bool enableFreezeMob;

		// Token: 0x04001380 RID: 4992
		public static bool enableHideChar;
	
		// Token: 0x04001381 RID: 4993
		public static bool enableHideNpc;

		// Token: 0x04001382 RID: 4994
		public static bool enableHideMob;

		// Token: 0x04001383 RID: 4995
		public static bool enableHideItem;

		// Token: 0x04001384 RID: 4996
		public static bool enableHideEffect;

		// Token: 0x04001385 RID: 4997
		public static bool enableHideBgItem;

		// Token: 0x04001386 RID: 4998
		public static bool enableHideBag;

		// Token: 0x04001387 RID: 4999
		public static bool enableHideServerNofitication;

		// Token: 0x04001388 RID: 5000
		public static bool enablePaintColor_Wallpaper;

		// Token: 0x04001389 RID: 5001
		public static bool enablePaintImage_Wallpaper;

		// Token: 0x0400138B RID: 5003
		public static int ColorRGB = 999999999;

		// Token: 0x0400138C RID: 5004
		public static bool enableHideGameUI;

		// Token: 0x0400138D RID: 5005
		public static bool enableHideTileMap;

		// Token: 0x0400138E RID: 5006
		public static bool enableOptimizingTileMap;

		// Token: 0x0400138F RID: 5007
		public static bool enableOptimizingCPU;

		// Token: 0x04001390 RID: 5008
		public static bool enableHideImage;

		// Token: 0x04001391 RID: 5009
		public static Image LogoLogin;

		// Token: 0x04001392 RID: 5010
		public static Image LogoGameScr;

		// Token: 0x04001393 RID: 5011
		public static bool enableSpecialUI = true;

		// Token: 0x04001393 RID: 5012

		public static bool listchar;
	}
}
