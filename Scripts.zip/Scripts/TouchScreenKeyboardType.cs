public enum TouchScreenKeyboardType
{
	Default,
	ASCIICapable,
	NumberPad
}
