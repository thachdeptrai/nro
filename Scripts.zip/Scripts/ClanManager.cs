public class ClanManager
{
	public static Clan[] clans;
}
