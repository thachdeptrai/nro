public class Layer
{
	public void update()
	{
	}

	public void paint(mGraphics g, int x, int y)
	{
	}

	public void keyPress(int keyCode)
	{
	}
}
