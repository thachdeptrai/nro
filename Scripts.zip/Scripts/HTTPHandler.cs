internal interface HTTPHandler
{
	void onGetText(string s);
}
