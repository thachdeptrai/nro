public class Archivement
{
	public string info1;

	public string info2;

	public int money;
	public short icon;
	public string textMoney;
	public bool isFinish;

	public bool isRecieve;
}
