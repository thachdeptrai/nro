public class PKFlag
{
	public sbyte cflag;

	public int IDimageFlag;
}
