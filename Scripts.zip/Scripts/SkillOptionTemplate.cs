public class SkillOptionTemplate
{
	public int id;

	public string name;
}
