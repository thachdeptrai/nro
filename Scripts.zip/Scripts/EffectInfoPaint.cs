public class EffectInfoPaint
{
	public int dx;

	public int dy;

	public int idImg;
}
