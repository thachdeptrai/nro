namespace Assets.src.e
{
	internal class ChatVip
	{
		public string chat;

		public int width;

		public int x;
	}
}
