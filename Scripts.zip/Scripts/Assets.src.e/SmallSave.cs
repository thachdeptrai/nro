namespace Assets.src.e
{
	internal class SmallSave
	{
		public sbyte[] data;

		public int id;
	}
}
