public class ItemObject
{
	public int id;

	public int where;

	public int type;

	public int indexX;

	public int indexY;

	public Image image;
}
