public class KeyConstant
{
	public const int KEY_NUM0 = 0;

	public const int KEY_NUM1 = 1;

	public const int KEY_NUM2 = 2;

	public const int KEY_NUM3 = 3;

	public const int KEY_NUM4 = 4;

	public const int KEY_NUM5 = 5;

	public const int KEY_NUM6 = 6;

	public const int KEY_NUM7 = 7;

	public const int KEY_NUM8 = 8;

	public const int KEY_NUM9 = 9;

	public const int KEY_STAR = 10;

	public const int KEY_BOUND = 11;

	public const int KEY_UP = 12;

	public const int KEY_DOWN = 13;

	public const int KEY_LEFT = 14;

	public const int KEY_RIGHT = 15;

	public const int KEY_FIRE = 16;

	public const int KEY_LEFT_SOFTKEY = 17;

	public const int KEY_RIGHT_SOFTKEY = 18;

	public const int KEY_CLEAR = 19;

	public const int KEY_BACK = 20;
}
