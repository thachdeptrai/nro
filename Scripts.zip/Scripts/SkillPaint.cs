public class SkillPaint
{
	public int id;

	public int effectHappenOnMob;

	public int numEff;

	public SkillInfoPaint[] skillStand;

	public SkillInfoPaint[] skillfly;
}
