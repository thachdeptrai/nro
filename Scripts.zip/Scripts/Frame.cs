public class Frame
{
	public short[] dx;

	public short[] dy;

	public sbyte[] idImg;
}
