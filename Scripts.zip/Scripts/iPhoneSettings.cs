public class iPhoneSettings
{
	public static iPhoneGeneration generation;

	public static iPhoneGeneration iPhone;

	public static iPhoneGeneration iPhone3G;

	public static iPhoneGeneration iPodTouch1Gen;

	public static iPhoneGeneration iPodTouch2Gen;
}
