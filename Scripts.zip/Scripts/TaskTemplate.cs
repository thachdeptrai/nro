public class TaskTemplate
{
	public short taskId;

	public string name;

	public string[] subNames;
}
