public class MobTemplate
{
	public sbyte mobTemplateId;

	public sbyte rangeMove;

	public sbyte speed;

	public sbyte type;

	public double hp;

	public string name;

	public EffectData data;

	public sbyte dartType;
}
