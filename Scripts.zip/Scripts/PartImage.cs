public class PartImage
{
	public short id;

	public sbyte dx;

	public sbyte dy;
}
