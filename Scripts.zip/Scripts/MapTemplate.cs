public class MapTemplate
{
	public static int[] tmw = new int[3];

	public static int[] tmh = new int[3];

	public static int[] pxw = new int[3];

	public static int[] pxh = new int[3];

	public static int[] tileID = new int[3];

	public static int[][] maps = new int[3][];

	public static int[][] types = new int[3][];

	public static MyVector[] vCurrItem = new MyVector[3];
}
