﻿
public class Role
{
    public short Small { get; set; }
    public int Frame { get; set; }
    public short Dx { get; set; }
    public short Dy { get; set; }
}