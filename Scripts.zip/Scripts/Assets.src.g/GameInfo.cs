namespace Assets.src.g
{
	internal class GameInfo
	{
		public string main;

		public string content;

		public short id;

		public bool hasRead;
	}
}
