public class EffectCharPaint
{
	public int idEf;

	public EffectInfoPaint[] arrEfInfo;
}
