public class NClass
{
	public int classId;

	public string name;

	public SkillTemplate[] skillTemplates;
}
