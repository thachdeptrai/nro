public class ItemOptionTemplate
{
	public int id;

	public string name;

	public int type;
}
