﻿public class mResources
{
	public static string learnSkill = string.Empty;

	public static string updSkill = string.Empty;

	public static string proficiency = string.Empty;

	public static string delacc = string.Empty;

	public static string notiINAPP = string.Empty;

	public static string notiRuby = string.Empty;

    public static string notify = string.Empty;

    public static string equip = string.Empty;

	public static string unlock = string.Empty;

	public static string radaCard = string.Empty;

	public static string not_enough_money_1 = string.Empty;

	public static string napngoc = string.Empty;

	public static string functionMaintain1 = string.Empty;

	public static string tang;

	public static string kquaVongQuay;

	public static string useGem;

	public static string autoFunction;

	public static string choitiep;

	public static string attack;

	public static string defend;

	public static string follow;

	public static string status;

	public static string gohome;

	public static string pet;

	public static string maychutathoacmatsong;

	public static string cauhinhthap;

	public static string cauhinhcao;

	public static string combineSpell;

	public static string combineFail;

	public static string combineSuccess;

	public static string turnOnAnalog;

	public static string turnOffAnalog;

	public static string analog;

	public static string inventory_Pass;

	public static string input_Inventory_Pass;

	public static string input_Inventory_Pass_wrong = string.Empty;

	public static string REGISTOPROTECT = string.Empty;

	public static string turnOnSound = string.Empty;

	public static string turnOffSound = string.Empty;

	public static string REGISTERING = string.Empty;

	public static string SENDINGMSG = string.Empty;

	public static string SENTMSG = string.Empty;

	public static string NOSENDMSG = string.Empty;

	public static string sendMsgSuccess = string.Empty;

	public static string cannotSendMsg = string.Empty;

	public static string sendGuessMsgSuccess = string.Empty;

	public static string sendMsgFail = string.Empty;

	public static string ALERT_PRIVATE_PASS_1 = string.Empty;

	public static string ALERT_PRIVATE_PASS_2 = string.Empty;

	public static string INPUT_PRIVATE_PASS = string.Empty;

	public static string change_account = string.Empty;

	public static string alreadyHadAccount1 = string.Empty;

	public static string alreadyHadAccount2 = string.Empty;

	public static string userBlank = string.Empty;

	public static string passwordBlank = string.Empty;

	public static string accTooShort = string.Empty;

	public static string phoneInvalid = string.Empty;

	public static string emailInvalid = string.Empty;

	public static string registerNewAcc = string.Empty;

	public static string selectServer = string.Empty;

	public static string selectServer2 = string.Empty;

	public static string forgetPass = string.Empty;

	public static string password = string.Empty;

	public static string[] LOGINLABELS = new string[2]
	{
		string.Empty,
		string.Empty
	};

	public static string msg = string.Empty;

	public static string[] msgg = new string[2]
	{
		string.Empty,
		string.Empty
	};

	public static string no_msg = string.Empty;

	public static string cancelAccountProtection = string.Empty;

	public static string plsCheckAcc = string.Empty;

	public static string phone = string.Empty;

	public static string email = string.Empty;

	public static string acc = string.Empty;

	public static string pwd = string.Empty;

	public static string goToWebForPassword = string.Empty;

	public static string dragon_ball = string.Empty;

	public static string character = string.Empty;

	public static string account = string.Empty;

	public static string account_server = string.Empty;

	public static string char_name_blank = string.Empty;

	public static string char_name_short = string.Empty;

	public static string char_name_long = string.Empty;

	public static string changeNameChar = string.Empty;

	public static string char_name = string.Empty;

	public static string login = string.Empty;

	public static string login2 = string.Empty;

	public static string register = string.Empty;

	public static string WAIT = string.Empty;

	public static string PLEASEWAIT = string.Empty;

	public static string CONNECTING = string.Empty;

	public static string LOGGING = string.Empty;

	public static string LOADING = string.Empty;

	public static string downloading_data = string.Empty;

	public static string select_server = string.Empty;

	public static string pls_restart_game_error = string.Empty;

	public static string lost_connection = string.Empty;

	public static string check_3G = string.Empty;

	public static string UPDATE = string.Empty;

	public static string change_zone = string.Empty;

	public static string select_zone = string.Empty;

	public static string website = string.Empty;

	public static string server = string.Empty;

	public static string planet = string.Empty;

	public static string QBMOD = string.Empty;

	public static string[] MENUME = new string[5]
	{
		string.Empty,
		string.Empty,
		string.Empty,
		string.Empty,
		string.Empty
	};

	public static string[] MENUNEWCHAR = new string[3]
	{
		string.Empty,
		string.Empty,
		string.Empty
	};

	public static string[] MENUGENDER = new string[3]
	{
		string.Empty,
		string.Empty,
		string.Empty
	};

	public static string[] CHAR_ORDER = new string[10]
	{
		string.Empty,
		string.Empty,
		string.Empty,
		string.Empty,
		string.Empty,
		string.Empty,
		string.Empty,
		string.Empty,
		string.Empty,
		string.Empty
	};

	public static string[][] mainTab1 = new string[4][]
	{
		new string[2]
		{
			string.Empty,
			string.Empty
		},
		new string[2]
		{
			string.Empty,
			string.Empty
		},
		new string[2]
		{
			string.Empty,
			string.Empty
		},
		new string[2]
		{
			string.Empty,
			string.Empty
		}
	};

	public static string[][] mainTab2 = new string[5][]
	{
		new string[2]
		{
			string.Empty,
			string.Empty
		},
		new string[2]
		{
			string.Empty,
			string.Empty
		},
		new string[2]
		{
			string.Empty,
			string.Empty
		},
		new string[2]
		{
			string.Empty,
			string.Empty
		},
		new string[2]
		{
			string.Empty,
			string.Empty
		}
	};

	public static string[][] petMainTab = new string[2][]
	{
		new string[2]
		{
			string.Empty,
			string.Empty
		},
		new string[2]
		{
			string.Empty,
			string.Empty
		}
	};

	public static string[][] petMainTab2 = new string[1][] { new string[2]
	{
		string.Empty,
		string.Empty
	} };

	public static string[] key_skill_qwerty = new string[10]
	{
		string.Empty,
		string.Empty,
		string.Empty,
		string.Empty,
		string.Empty,
		string.Empty,
		string.Empty,
		string.Empty,
		string.Empty,
		string.Empty
	};

	public static string[] key_skill = new string[10]
	{
		string.Empty,
		string.Empty,
		string.Empty,
		string.Empty,
		string.Empty,
		string.Empty,
		string.Empty,
		string.Empty,
		string.Empty,
		string.Empty
	};

	public static string SKILL_FAIL = string.Empty;

	public static string HP_EMPTY = string.Empty;

	public static string ZONE_HERE = string.Empty;

	public static string[] DES_TASK = new string[4]
	{
		" ",
		string.Empty,
		string.Empty,
		string.Empty
	};

	public static string[] DIES = new string[4]
	{
		string.Empty,
		string.Empty,
		string.Empty,
		string.Empty
	};

	public static string[] SYNTHESIS = new string[3]
	{
		string.Empty,
		string.Empty,
		string.Empty
	};

	public static string[] tips = new string[12]
	{
		string.Empty,
		string.Empty,
		string.Empty,
		string.Empty,
		string.Empty,
		string.Empty,
		string.Empty,
		string.Empty,
		string.Empty,
		string.Empty,
		string.Empty,
		string.Empty
	};

	public static string TASK_INPUT_CLASS = string.Empty;

	public static string SERI_NUM = string.Empty;

	public static string CARD_CODE = string.Empty;

	public static string pay_card = string.Empty;

	public static string pay_card2 = string.Empty;

	public static string serial_blank = string.Empty;

	public static string card_code_blank = string.Empty;

	public static string billion = string.Empty;

	public static string million = string.Empty;

	public static string MENU = string.Empty;

	public static string CLOSE = string.Empty;

	public static string ON = string.Empty;

	public static string OFF = string.Empty;

	public static string ENABLE = string.Empty;

	public static string DELETE = string.Empty;

	public static string VIEW = string.Empty;

	public static string CONTINUE = string.Empty;

	public static string NEXTSTEP = string.Empty;

	public static string USE = string.Empty;

	public static string SORT = string.Empty;

	public static string YES = string.Empty;

	public static string NO = string.Empty;

	public static string EXIT = string.Empty;

	public static string CHAT = string.Empty;

	public static string REVENGE = string.Empty;

	public static string OK = string.Empty;

	public static string retry = string.Empty;

	public static string uncheck = string.Empty;

	public static string remember = string.Empty;

	public static string ACCEPT = string.Empty;

	public static string CANCEL = string.Empty;

	public static string SELECT = string.Empty;

	public static string enter = string.Empty;

	public static string open_link = string.Empty;

	public static string DOYOUWANTEXIT = string.Empty;

	public static string NEWCHAR = string.Empty;

	public static string BACK = string.Empty;

	public static string LOCKED = string.Empty;

	public static string KILL = string.Empty;

	public static string KILLBOSS = string.Empty;

	public static string NOLOCK = string.Empty;

	public static string XU = string.Empty;

	public static string LUONG = string.Empty;

	public static string RUBY = string.Empty;

	public static string PK_NOW = string.Empty;

	public static string CUU_SAT = string.Empty;

	public static string NOT_ENOUGH_MP = string.Empty;

	public static string you_receive = string.Empty;

	public static string MONTH = string.Empty;

	public static string WEEK = string.Empty;

	public static string DAY = string.Empty;

	public static string HOUR = string.Empty;

	public static string SECOND = string.Empty;

	public static string MINUTE = string.Empty;

	public static string LEARN_SKILL = string.Empty;

	public static string rank = string.Empty;

	public static string active_point = string.Empty;

	public static string friend = string.Empty;

	public static string enemy = string.Empty;

	public static string no_friend = string.Empty;

	public static string chat_world = string.Empty;

	public static string change_flag = string.Empty;

	public static string gameInfo = string.Empty;

	public static string quayso = string.Empty;

	public static string option = string.Empty;

	public static string high = string.Empty;

	public static string medium = string.Empty;

	public static string low = string.Empty;

	public static string increase_vga = string.Empty;

	public static string decrease_vga = string.Empty;

	public static string serverchat_off = string.Empty;

	public static string serverchat_on = string.Empty;

	public static string x2Screen = string.Empty;

	public static string x1Screen = string.Empty;

	public static string changeSizeScreen = string.Empty;

	public static string aura_off = string.Empty;

	public static string aura_on = string.Empty;

	public static string aura_off_2 = string.Empty;

	public static string aura_on_2 = string.Empty;

	public static string hat_off = string.Empty;

	public static string hat_on = string.Empty;

	public static string chest = string.Empty;

	public static string[] chestt = new string[2]
	{
		string.Empty,
		string.Empty
	};

	public static string[] inventory = new string[2]
	{
		string.Empty,
		string.Empty
	};

	public static string[] combine = new string[2]
	{
		string.Empty,
		string.Empty
	};

	public static string[] mapp = new string[2]
	{
		string.Empty,
		string.Empty
	};

	public static string[] item_give = new string[2]
	{
		string.Empty,
		string.Empty
	};

	public static string[] item_receive = new string[2]
	{
		string.Empty,
		string.Empty
	};

	public static string[] zonee = new string[2]
	{
		string.Empty,
		string.Empty
	};

	public static string zone = string.Empty;

	public static string map = string.Empty;

	public static string item_receive2 = string.Empty;

	public static string item = string.Empty;

	public static string give_upper = string.Empty;

	public static string receive_upper = string.Empty;

	public static string receive_all = string.Empty;

	public static string no_map = string.Empty;

	public static string go_to_quest = string.Empty;

	public static string from_earth = string.Empty;

	public static string from_namec = string.Empty;

	public static string from_sayda = string.Empty;

	public static string expire = string.Empty;

	public static string pow_request = string.Empty;

	public static string your_pow = string.Empty;

	public static string used = string.Empty;

	public static string place = string.Empty;

	public static string FOREVER = string.Empty;

	public static string NOUPGRADE = string.Empty;

	public static string NOTUPGRADE = string.Empty;

	public static string UPGRADE = string.Empty;

	public static string UPGRADING = string.Empty;

	public static string make_shortcut = string.Empty;

	public static string into_place = string.Empty;

	public static string move_to_chest = string.Empty;

	public static string move_to_chest2 = string.Empty;

	public static string press_chat_querty = string.Empty;

	public static string press_chat = string.Empty;

	public static string saying = string.Empty;

	public static string miss = string.Empty;

	public static string donate = string.Empty;

	public static string receive = string.Empty;

	public static string press_twice = string.Empty;

	public static string can_harvest = string.Empty;

	public static string do_accept_qwerty = string.Empty;

	public static string do_accept = string.Empty;

	public static string plsRestartGame = string.Empty;

	public static string is_online = string.Empty;

	public static string is_offline = string.Empty;

	public static string make_friend = string.Empty;

	public static string chat_player = string.Empty;

	public static string chat_with = string.Empty;

	public static string clan_capsuledonate = string.Empty;

	public static string clan_capsuleself = string.Empty;

	public static string clan_point = string.Empty;

	public static string give_pea = string.Empty;

	public static string receive_pea = string.Empty;

	public static string request_pea = string.Empty;

	public static string time = string.Empty;

	public static string received = string.Empty;

	public static string power = string.Empty;

	public static string join_date = string.Empty;

	public static string clan_leader = string.Empty;

	public static string clan_coleader = string.Empty;

	public static string power_point = string.Empty;

	public static string member = string.Empty;

	public static string[] memberr = new string[2]
	{
		string.Empty,
		string.Empty
	};

	public static string[] chatClan = new string[2]
	{
		string.Empty,
		string.Empty
	};

	public static string[] leaveClan = new string[2]
	{
		string.Empty,
		string.Empty
	};

	public static string[] createClan = new string[2]
	{
		string.Empty,
		string.Empty
	};

	public static string[] findClan = new string[2]
	{
		string.Empty,
		string.Empty
	};

	public static string[] khau_hieuu = new string[1] { string.Empty };

	public static string[] bieu_tuongg = new string[1] { string.Empty };

	public static string[] request_pea2 = new string[2]
	{
		string.Empty,
		string.Empty
	};

	public static string level = string.Empty;

	public static string clan_birthday = string.Empty;

	public static string clan_list = string.Empty;

	public static string create = string.Empty;

	public static string find = string.Empty;

	public static string leave = string.Empty;

	public static string not_join_clan = string.Empty;

	public static string[] clanEmpty = new string[5]
	{
		string.Empty,
		string.Empty,
		string.Empty,
		string.Empty,
		string.Empty
	};

	public static string input_clan_name = string.Empty;

	public static string clan_name = string.Empty;

	public static string chat_clan = string.Empty;

	public static string input_clan_name_to_create = string.Empty;

	public static string input_clan_slogan = string.Empty;

	public static string do_u_want_join_clan = string.Empty;

	public static string select_clan_icon = string.Empty;

	public static string request_join_clan = string.Empty;

	public static string view_clan_member = string.Empty;

	public static string create_clan_co_leader = string.Empty;

	public static string create_clan_leader = string.Empty;

	public static string disable_clan_mastership = string.Empty;

	public static string kick_clan_mem = string.Empty;

	public static string clan_name_blank = string.Empty;

	public static string clan_slogan_blank = string.Empty;

	public static string cannot_find_clan = string.Empty;

	public static string ago = string.Empty;

	public static string findingClan = string.Empty;

	public static string trade = string.Empty;

	public static string not_lock_trade = string.Empty;

	public static string not_lock_trade_upper = string.Empty;

	public static string locked_trade = string.Empty;

	public static string locked_trade_upper = string.Empty;

	public static string lock_trade = string.Empty;

	public static string wait_opp_lock_trade = string.Empty;

	public static string press_done = string.Empty;

	public static string THROW = string.Empty;

	public static string SPLIT = string.Empty;

	public static string done = string.Empty;

	public static string opponent = string.Empty;

	public static string you = string.Empty;

	public static string mlock = string.Empty;

	public static string money_trade = string.Empty;

	public static string GETOUT = string.Empty;

	public static string MOVEOUT = string.Empty;

	public static string MOVEFORPET = string.Empty;

	public static string GETOUTMONEY = string.Empty;

	public static string GETINMONEY = string.Empty;

	public static string SENDMONEY = string.Empty;

	public static string GETIN = string.Empty;

	public static string SALE = string.Empty;

	public static string SALES = string.Empty;

	public static string SALEALL = string.Empty;

	public static string BUY = string.Empty;

	public static string BUYS = string.Empty;

	public static string input_money_to_trade = string.Empty;

	public static string input_money = string.Empty;

	public static string input_money_wrong = string.Empty;

	public static string not_enough_money = string.Empty;

	public static string input_quantity_to_trade = string.Empty;

	public static string input_quantity = string.Empty;

	public static string input_quantity_wrong = string.Empty;

	public static string already_has_item = string.Empty;

	public static string unlock_item_to_trade = string.Empty;

	public static string root = string.Empty;

	public static string need = string.Empty;

	public static string need_upper = string.Empty;

	public static string free = string.Empty;

	public static string free1 = string.Empty;

	public static string free2 = string.Empty;

	public static string select_item = string.Empty;

	public static string random = string.Empty;

	public static string say_hello = string.Empty;

	public static string say_wat_do_u_want_to_buy = string.Empty;

	public static string say_wat_do_u_want_to_buy2 = string.Empty;

	public static string do_u_sure_to_trade = string.Empty;

	public static string learn_with = string.Empty;

	public static string buy_with = string.Empty;

	public static string can_not_do_when_die = string.Empty;

	public static string use_for_combine = string.Empty;

	public static string use_for_trade = string.Empty;

	public static string not_enough_luong_world_channel = string.Empty;

	public static string world_channel_5_luong = string.Empty;

	public static string want_to_trade = string.Empty;

	public static string hasJustUpgrade1 = string.Empty;

	public static string hasJustUpgrade2 = string.Empty;

	public static string potential_to_learn = string.Empty;

	public static string potential_point = string.Empty;

	public static string achievement_point = string.Empty;

	public static string increase = string.Empty;

	public static string increase_upper = string.Empty;

	public static string not_enough_potential_point1 = string.Empty;

	public static string not_enough_potential_point2 = string.Empty;

	public static string use_potential_point_for1 = string.Empty;

	public static string use_potential_point_for2 = string.Empty;

	public static string for_HP = string.Empty;

	public static string for_KI = string.Empty;

	public static string for_hit_point = string.Empty;

	public static string for_armor = string.Empty;

	public static string for_crit = string.Empty;

	public static string can_buy_from_Uron1 = string.Empty;

	public static string can_buy_from_Uron2 = string.Empty;

	public static string can_buy_from_Uron3 = string.Empty;

	public static string HP = string.Empty;

	public static string KI = string.Empty;

	public static string hit_point = string.Empty;

	public static string armor = string.Empty;

	public static string vitality = string.Empty;

	public static string critical = string.Empty;

	public static string cap_do = string.Empty;

	public static string KI_consume = string.Empty;

	public static string cooldown = string.Empty;

	public static string milisecond = string.Empty;

	public static string max_level_reach = string.Empty;

	public static string next_level_require = string.Empty;

	public static string potential = string.Empty;

	public static string not_learn = string.Empty;

	public static string learn_require = string.Empty;

	public static string learn = string.Empty;

	public static string to_gain_20hp = string.Empty;

	public static string to_gain_20mp = string.Empty;

	public static string to_gain_1pow = string.Empty;

	public static string[][] hairStyleName = new string[3][]
	{
		new string[3]
		{
			string.Empty,
			string.Empty,
			string.Empty
		},
		new string[3]
		{
			string.Empty,
			string.Empty,
			string.Empty
		},
		new string[3]
		{
			string.Empty,
			string.Empty,
			string.Empty
		}
	};

	public static string hp_ki_full = string.Empty;

	public static string quest_place = string.Empty;

	public static string no_mission = string.Empty;

	public static string reward_mission = string.Empty;

	public static string achievement_mission = string.Empty;

	public static string trangbi = string.Empty;

	public static string wat_do_u_want = string.Empty;

	public static string off = string.Empty;

	public static string on = string.Empty;

	public static string select_map = string.Empty;

	public static string offPlease = string.Empty;

	public static string onPlease = string.Empty;

	public static sbyte language;

	public const sbyte VIETNAM = 0;

	public const sbyte ENGLISH = 1;

	public const sbyte INDONESIA = 2;

	public static string choigame;

	public static string no_enemy = string.Empty;

	public static string kigui;

	public static string kiguiXu;

	public static string kiguiLuong;

	public static string kiguiXuchat;

	public static string kiguiLuongchat;

	public static string huykigui;

	public static string nhantien;

	public static string dangban;

	public static string daban;

	public static string num;

	public static string upTop;

	public static string page;

	public static string getDown;

	public static string getUp;

	public static string notYetSell;

	public static string charger;

	public static string finishBomong;

	public static string note;

	public static string regNote;

	public static string remain;

	public static string faster;

	public static string fasterQuestion;

	public static string chuacotaikhoan;

	public static string taidulieudechoi;

	public static string huy;

	public static string taidulieu;

	public static string xoadulieu;

	public static string deletaDataNote;

	public static string playNew;

	public static string playAcc;

	public static string vuilongnhapduthongtin;

	public static string not_register_yet = string.Empty;

	public static string nhanngoc;

	public static string fusion;

	public static string sure_fusion;

	public static string fusionForever;

	public static string xinchucmung;

	public static string den;

	public static string nhatvatpham;

	public static void loadLanguague()
	{
		loadLanguague(1);
	}

	public static void loadLanguague(sbyte newLanguage)
	{
		language = newLanguage;
		switch (language)
		{
		case 0:
			LoginScr.imgTitle = GameCanvas.loadImage("/mainImage/logo1.png");
			T1.load();
			ServerListScreen.linkweb = "Queen Bee Mods";
			break;
		case 1:
			LoginScr.imgTitle = GameCanvas.loadImage("/mainImage/logo1E.png");
			T2.load();
			ServerListScreen.linkweb = "Queen Bee Mods";
			break;
		case 2:
			LoginScr.imgTitle = GameCanvas.loadImage("/mainImage/logo1E.png");
			T3.load();
			ServerListScreen.linkweb = "Queen Bee Mods";
			break;
		}
	}

	public static string replace(string str, string replacement)
	{
		return NinjaUtil.replace(str, "#", replacement);
	}
}
