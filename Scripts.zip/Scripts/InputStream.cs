using System;
using System.IO;
using System.Linq;

public class InputStream : myReader
{   private sbyte[] buffer;

	public InputStream()
	{
	}

	public InputStream(sbyte[] data)
	{
		buffer = data;
	}

	public InputStream(string filename)
		: base(filename)
	{
	}
    // Giả sử bạn có một phương thức để chuyển đổi sbyte[] thành Stream
    public Stream ToStream()
    {
        if (buffer != null)
        {
            return new MemoryStream(buffer.Select(b => (byte)b).ToArray());
        }
        else
        {
            throw new InvalidOperationException("Buffer is null.");
        }
    }
}
