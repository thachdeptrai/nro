public class DartInfo
{
	public short id;

	public short[][] head;

	public short[][] headBorder;

	public short[] tail;

	public short[] tailBorder;

	public short[] xd1;

	public short[] xd2;

	public short xdPercent;

	public short nUpdate;

	public int va;
}
